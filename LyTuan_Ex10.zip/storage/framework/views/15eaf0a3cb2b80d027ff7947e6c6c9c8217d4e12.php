<?php $__env->startSection('content'); ?>
<?php foreach($edit_data as $data): ?>
<table border="1px" margin-left="100px">
	
		<form action="" method="POST" style="width:650px;">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			
			<input type="text" name="txtmasv" value="<?php echo $data["masv"]; ?>">
			<input type="text" name='txtten' value="<?php echo $data['ten']; ?>">
			<input type="text" name='txtlop' value="<?php echo $data['lop']; ?>">
			
			<input type="submit" value='Chỉnh sửa xong'>
		</form>
	
</table>
<?php endforeach; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>