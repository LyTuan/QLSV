<?php if(count($errors) > 0): ?>
    
        <ul class="error_msg">
            <?php foreach($errors->all() as $error): ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; ?>
        </ul>
    
<?php endif; ?>