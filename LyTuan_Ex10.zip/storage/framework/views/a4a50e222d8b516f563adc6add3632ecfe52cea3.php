<?php $__env->startSection('content'); ?>
	    <table border="1px" margin-left="100px">
			<caption text-align="center">Danh sách sinh viên</caption>
			<thead>
				<tr>
					<th>id</th>
					<th>Mã SV</th>
					<th>Tên</th>
					<th>Lớp</th>
				</tr>
			</thead>
			<tbody>
			<?php foreach($sinhvien_data as $data): ?>
				<tr>
					<td><?php echo $data['id']; ?></td>
					<td><?php echo $data['masv']; ?></td>
					<td><?php echo $data['ten']; ?></td>
					<td><?php echo $data['lop']; ?></td>
					<td><a href="edit/<?php echo $data['id']; ?>" ><img src="<?php echo asset('/templates/images/edit.png'); ?>" alt="delete icon"></a></td>
					<td><a href="delete/<?php echo $data['id']; ?>"  onclick="return xacNhanXoa('Bạn có chắc chắn muốn xóa')"><img src="<?php echo asset('/templates/images/delete.png'); ?>" alt="delete icon"></a></td>
				</tr>
			<?php endforeach; ?>
			<?php echo $__env->make('blocks.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<form action="" method="post" style="width:650px;">
				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
				<input type="text" name="txtmasv" placeholder="Mã Sinh viên">
				<input type="text" name='txtten' placeholder="Tên">
				<input type="text" name='txtlop' placeholder="Lớp">
				<input type="submit" value='Thêm vào danh sách'>
			</form>
			</tbody>
	</table>
<?php $__env->stopSection(); ?>	

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>