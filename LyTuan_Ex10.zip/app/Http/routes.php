<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('sinhvien',['as' => 'getInfo', 'uses' => 'SinhVienController@getInfo']);
Route::post('sinhvien',['as'=>'postAddSinhVien','uses'=>'SinhVienController@postAddSinhVien']);
Route::get('delete/{id}',['as'=>'deletedsinhvien','uses'=>'SinhVienController@deletedsinhvien']);
Route::get('edit/{id}',['as'=>'editSinhvien','uses'=>'SinhVienController@editSinhvien']);
Route::post('edit/{id}',['as'=>'postEditSinhVien','uses' =>'SinhVienController@postEditSinhVien']);