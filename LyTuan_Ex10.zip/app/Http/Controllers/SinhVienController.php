<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\sinhvien;
use App\Http\Requests\SinhVienRequest;
use App\Http\Requests\SinhVienEditRequest;

class SinhVienController extends Controller
{
        public function getInfo () {
    	$data = sinhvien::select('id','masv','ten','lop')->get()->toArray();

			return view('sinhvien',['sinhvien_data' => $data]);
		}
		public function postAddSinhVien(SinhVienRequest $request){
			$sinhvien = new sinhvien;
			$sinhvien->masv = $request->txtmasv;
			$sinhvien ->ten= $request->txtten;
			$sinhvien->lop = $request->txtlop;
			$sinhvien->save();
			return redirect()->route('getInfo');

		}
		public function deletedSinhVien($id){
			$sinhvien = sinhvien::find($id);
			$sinhvien->delete();
			return redirect()->route('getInfo');
		}
		public function editSinhVien($id){
			$data = sinhvien::where('id',$id)->get()->toArray();
			return view('editSinhvien',['edit_data'=>$data]);
		}
		public function postEditSinhVien(SinhVienEditRequest $request,$id){
			$sinhvien =  sinhvien::find($id);
			$sinhvien->masv = $request->txtmasv;
			$sinhvien ->ten= $request->txtten;
			$sinhvien->lop = $request->txtlop;
			$sinhvien->save();
			return redirect()->route('getInfo');
		}
}
